/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28/10/2015 11:40:28                         ---
 * ----------------------------------------------------------------
 */
package de.fliegersoftware.amazon.hmc.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAmazonhmcaddonConstants
{
	public static final String EXTENSIONNAME = "amazonhmcaddon";
	
	protected GeneratedAmazonhmcaddonConstants()
	{
		// private constructor
	}
	
	
}
