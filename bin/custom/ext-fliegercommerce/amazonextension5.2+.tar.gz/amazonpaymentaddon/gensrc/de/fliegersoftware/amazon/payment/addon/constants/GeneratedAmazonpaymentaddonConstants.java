/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28/10/2015 11:40:28                         ---
 * ----------------------------------------------------------------
 */
package de.fliegersoftware.amazon.payment.addon.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAmazonpaymentaddonConstants
{
	public static final String EXTENSIONNAME = "amazonpaymentaddon";
	public static class TC
	{
		public static final String AMAZONADDRESSBOOKCOMPONENT = "AmazonAddressBookComponent".intern();
		public static final String AMAZONPAYBUTTONCOMPONENT = "AmazonPayButtonComponent".intern();
		public static final String AMAZONWALLETCOMPONENT = "AmazonWalletComponent".intern();
	}
	
	protected GeneratedAmazonpaymentaddonConstants()
	{
		// private constructor
	}
	
	
}
