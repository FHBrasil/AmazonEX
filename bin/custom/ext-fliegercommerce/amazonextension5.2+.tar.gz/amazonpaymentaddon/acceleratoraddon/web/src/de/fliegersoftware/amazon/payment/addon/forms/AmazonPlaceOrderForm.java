package de.fliegersoftware.amazon.payment.addon.forms;

public class AmazonPlaceOrderForm {

	private String amazonOrderReferenceId;

	public AmazonPlaceOrderForm() {
	}

	public String getAmazonOrderReferenceId() {
		return amazonOrderReferenceId;
	}

	public void setAmazonOrderReferenceId(String amazonOrderReferenceId) {
		this.amazonOrderReferenceId = amazonOrderReferenceId;
	}
}