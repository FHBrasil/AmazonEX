/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28/10/2015 11:40:28                         ---
 * ----------------------------------------------------------------
 */
package de.fliegersoftware.amazon.payment.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAmazonpaymentConstants
{
	public static final String EXTENSIONNAME = "amazonpayment";
	public static class TC
	{
		public static final String AMAZONBASECRONJOB = "AmazonBaseCronJob".intern();
	}
	public static class Attributes
	{
		public static class Cart
		{
			public static final String PRECREATEDORDERCODE = "preCreatedOrderCode".intern();
		}
	}
	public static class Enumerations
	{
		public static class PaymentTransactionType
		{
			public static final String REFUND = "REFUND".intern();
		}
	}
	
	protected GeneratedAmazonpaymentConstants()
	{
		// private constructor
	}
	
	
}
