package de.fliegersoftware.amazon.payment.dto;

public enum AmazonTransactionStatus {
	Pending, Open, Closed, Declined, Canceled, Completed, Suspended, Draft, Stale
}
