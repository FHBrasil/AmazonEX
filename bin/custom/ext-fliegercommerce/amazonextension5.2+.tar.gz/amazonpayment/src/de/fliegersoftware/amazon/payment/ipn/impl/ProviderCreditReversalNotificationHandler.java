package de.fliegersoftware.amazon.payment.ipn.impl;

import com.amazonservices.mws.offamazonpaymentsipn.model.ProviderCreditReversalNotification;

public class ProviderCreditReversalNotificationHandler extends BaseAmazonNotificationHandler<ProviderCreditReversalNotification> {

	@Override
	public void log(ProviderCreditReversalNotification notification) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void handle(ProviderCreditReversalNotification notification) {
		// TODO Auto-generated method stub
	}
}