package de.fliegersoftware.amazon.payment.ipn.impl;

import com.amazonservices.mws.offamazonpaymentsipn.model.ProviderCreditNotification;

public class ProviderCreditNotificationHandler extends BaseAmazonNotificationHandler<ProviderCreditNotification> {

	@Override
	public void log(ProviderCreditNotification notification) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void handle(ProviderCreditNotification notification) {
		// TODO Auto-generated method stub
	}
}