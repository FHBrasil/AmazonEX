package de.fliegersoftware.amazon.payment.ipn.impl;

import com.amazonservices.mws.offamazonpaymentsipn.model.SolutionProviderMerchantNotification;

public class SolutionProviderMerchantNotificationHandler extends BaseAmazonNotificationHandler<SolutionProviderMerchantNotification> {

	@Override
	public void log(SolutionProviderMerchantNotification notification) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void handle(SolutionProviderMerchantNotification notification) {
		// TODO Auto-generated method stub
	}
}