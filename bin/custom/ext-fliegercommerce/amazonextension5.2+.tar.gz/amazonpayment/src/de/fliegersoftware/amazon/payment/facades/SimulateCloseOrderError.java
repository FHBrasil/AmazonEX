package de.fliegersoftware.amazon.payment.facades;

public enum SimulateCloseOrderError {
	None
	, AmazonClosed
}
