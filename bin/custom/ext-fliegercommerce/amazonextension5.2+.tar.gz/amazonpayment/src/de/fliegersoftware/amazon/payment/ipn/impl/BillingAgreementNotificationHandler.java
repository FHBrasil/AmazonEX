package de.fliegersoftware.amazon.payment.ipn.impl;

import com.amazonservices.mws.offamazonpaymentsipn.model.BillingAgreementNotification;

public class BillingAgreementNotificationHandler extends BaseAmazonNotificationHandler<BillingAgreementNotification> {

	@Override
	public void log(BillingAgreementNotification notification) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void handle(BillingAgreementNotification notification) {
		// TODO Auto-generated method stub
	}
}