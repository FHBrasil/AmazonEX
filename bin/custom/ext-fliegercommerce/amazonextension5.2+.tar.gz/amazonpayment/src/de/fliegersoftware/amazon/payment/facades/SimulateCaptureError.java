package de.fliegersoftware.amazon.payment.facades;

public enum SimulateCaptureError {
	None
	, CapturePending, AmazonRejected, AmazonClosed
}
