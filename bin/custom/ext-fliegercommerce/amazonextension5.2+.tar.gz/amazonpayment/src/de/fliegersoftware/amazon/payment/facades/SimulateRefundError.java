package de.fliegersoftware.amazon.payment.facades;

public enum SimulateRefundError {
	None
	, AmazonRejected
}
