/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28/10/2015 11:40:28                         ---
 * ----------------------------------------------------------------
 */
package de.fliegersoftware.amazon.login.addon.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAmazonloginaddonConstants
{
	public static final String EXTENSIONNAME = "amazonloginaddon";
	public static class TC
	{
		public static final String AMAZONLOGINCOMPONENT = "AmazonLoginComponent".intern();
	}
	
	protected GeneratedAmazonloginaddonConstants()
	{
		// private constructor
	}
	
	
}
